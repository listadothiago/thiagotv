#!/usr/bin/env python3
"""Generate the crawlable half of a RetroTV station.

The TV itself is a JavaScript application: it fetches playlist.json and paints
the screen. That's fine for a person, but a crawler fetching index.html sees an
empty div where the programme notes should be, and the LLM crawlers that matter
here (GPTBot, ClaudeBot, PerplexityBot) generally don't run JavaScript at all.

So the notes are also emitted as plain static HTML, one page per video, at
publish time. Those pages are the citable artefacts: each has its own URL, its
own title and description, and schema.org markup describing the video. The TV
stays the front door and links into them.

Everything under v/ and the files listed in GENERATED are outputs. Don't hand
edit them; edit playlist.json and run this again.

Usage:
    python3 scripts/build.py [--base-url https://example.com]
"""

import argparse
import datetime as dt
import html
import json
import re
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PLAYLIST = ROOT / "playlist.json"
VIDEO_DIR = ROOT / "v"
CHANNEL_DIR = ROOT / "c"
POST_SRC = ROOT / "posts"
POST_OUT = ROOT / "p"

GENERATED = ["guide.html", "notes.css", "sitemap.xml", "robots.txt", "station.json"]

STATION_SPEC = 1
LATEST_COUNT = 10

SECTIONS = [
    ("summary", "Summary"),
    ("relevance", "Why it matters"),
    ("controversy", "Controversy"),
]

ANALYTICS = '''<script defer src="/_vercel/insights/script.js"></script>'''

# Every station built from this template credits the same place back by
# default -- the page that hands out the plugin and walks someone through
# building their own. A station owner can strip this line, but it shouldn't
# take active effort to end up without it.
RETROTV_HOME = "https://thiagotv.vercel.app/create-your-tv.html"
RETROTV_CREDIT = (
    f'<p class="credit">Powered by <a href="{RETROTV_HOME}">RetroTV</a> '
    f'&mdash; build your own</p>'
)

def read_posts():
    """Posts are markdown files in posts/, with a small frontmatter block.

    Kept as files rather than as JSON strings because these are the one thing on
    the site written at length, and long prose belongs somewhere you can actually
    write it.
    """
    if not POST_SRC.exists():
        return []
    posts = []
    for path in sorted(POST_SRC.glob("*.md")):
        raw = path.read_text()
        meta, _, body = raw.partition("\n---\n") if raw.startswith("---\n") else ("", "", raw)
        fields = {}
        for line in meta.lstrip("-\n").splitlines():
            if ":" in line:
                k, _, v = line.partition(":")
                fields[k.strip().lower()] = v.strip()
        posts.append({
            "slug": path.stem,
            "title": fields.get("title", path.stem),
            "date": fields.get("date", ""),
            "summary": fields.get("summary", ""),
            "body": body.strip(),
        })
    posts.sort(key=lambda p: p["date"], reverse=True)
    return posts


def render_markdown(text, videos_by_id, prefix=""):
    """A deliberately small markdown subset: headings, paragraphs, lists, links,
    emphasis -- and [[videoId]], which expands to a link carrying the programme's
    real title, so a post can never drift out of step with the schedule.

    Everything is escaped first and marked up second, so nothing written in a
    post can inject HTML.
    """
    mentioned = []
    unresolved = []

    def inline(t):
        t = esc(t)
        def video(m):
            vid = m.group(1)
            v = videos_by_id.get(vid)
            if not v:
                # Loud on purpose. An unresolved reference means someone wrote an
                # id for a programme that isn't on the station -- which in
                # practice means it was invented -- and it would otherwise ship
                # as raw brackets in the middle of a paragraph.
                unresolved.append(vid)
                return ""
            if vid not in mentioned:
                mentioned.append(vid)
            return f'<a href="{prefix}v/{esc(vid)}.html">{esc(v.get("title", vid))}</a>'
        t = re.sub(r"\[\[([A-Za-z0-9_-]{11})\]\]", video, t)
        t = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', t)
        t = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", t)
        t = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"<em>\1</em>", t)
        return t

    html_parts, bullets = [], []

    def flush():
        if bullets:
            html_parts.append("<ul>" + "".join(f"<li>{b}</li>" for b in bullets) + "</ul>")
            bullets.clear()

    for block in re.split(r"\n\s*\n", text):
        block = block.strip()
        if not block:
            continue
        if block.startswith("## "):
            flush()
            html_parts.append(f"<h2>{inline(block[3:].strip())}</h2>")
        elif all(line.lstrip().startswith("- ") for line in block.splitlines()):
            for line in block.splitlines():
                bullets.append(inline(line.lstrip()[2:]))
            flush()
        else:
            flush()
            html_parts.append(f"<p>{inline(block)}</p>")
    flush()
    if unresolved:
        print(f"  WARNING: post references {len(unresolved)} unknown video id(s): "
              f"{', '.join(unresolved)}", file=sys.stderr)
    return "\n".join(html_parts), mentioned


MONTH_NAMES = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December",
]

WATCHED_SCRIPT = '''<script>
/* Marks what this visitor has already watched, reading the same localStorage the
   set writes. Kept out of the generated HTML on purpose: the page is identical
   for everyone and for crawlers, and the personal layer is added client-side. */
(function () {
  var seen;
  try {
    seen = JSON.parse(localStorage.getItem('retrotv.seen.v1') || '{}');
  } catch (e) { return; }

  var resume;
  try {
    resume = JSON.parse(localStorage.getItem('retrotv.resume.v1') || '{}');
  } catch (e) { resume = {}; }

  // Only real programmes -- the date headings are list items too, and counting
  // them would inflate the total.
  var items = document.querySelectorAll('#programmes li[data-id]');
  var watched = 0;

  Array.prototype.forEach.call(items, function (li) {
    var id = li.getAttribute('data-id');
    var part = resume[id];
    // Part-watched is more useful to say than watched: it's the thing you might
    // want to go back to.
    // Not every row carries a tag line -- on a channel page it only appears
    // when the programme is also on another channel -- so the mark goes after
    // the title when there's nowhere else for it.
    var slot = li.querySelector('.tags') || li.querySelector('a');
    if (part && typeof part.t === 'number' && part.t > 30) {
      li.classList.add('part-watched');
      var m = Math.floor(part.t / 60), s = Math.floor(part.t % 60);
      slot.insertAdjacentHTML(
        'afterend',
        ' <em class="mark">stopped at ' + m + ':' + (s < 10 ? '0' : '') + s + '</em>'
      );
      watched++;
      return;
    }
    if (Object.prototype.hasOwnProperty.call(seen, id)) {
      li.classList.add('watched');
      slot.insertAdjacentHTML('afterend', ' <em class="mark">watched</em>');
      watched++;
    }
  });

  var summary = document.getElementById('watchedSummary');
  if (summary && items.length) {
    summary.textContent = watched
      ? 'You have watched ' + watched + ' of ' + items.length + ' programmes.'
      : '';
  }
})();
</script>'''

STYLESHEET = """\
/* Generated by scripts/build.py -- edit the script, not this file. */
*, *::before, *::after { box-sizing: border-box; }
body {
  margin: 0;
  padding: 32px 20px 64px;
  background: radial-gradient(ellipse at 50% 0%, #1b3a6b 0%, #12244a 45%, #070f22 100%);
  background-attachment: fixed;
  font-family: 'Courier New', monospace;
  color: #2b2115;
}
.sheet {
  max-width: 760px;
  margin: 0 auto;
  background: linear-gradient(180deg, rgba(120,90,50,.10), transparent 220px), #efe4cd;
  padding: 44px 48px 36px;
  border-top: 1px solid #f7efdd;
  border-bottom: 1px solid #c5b391;
  box-shadow: 0 1px 0 rgba(255,255,255,.5) inset, 0 18px 44px rgba(0,0,0,.55);
}
.eyebrow {
  font-size: 11px; letter-spacing: 4px; text-transform: uppercase;
  color: #7a6444; margin: 0 0 8px;
}
/* The way back to the television, at the top and hard to miss. Someone who
   arrives here from a search should be able to see where they are and get to
   the thing itself in one move -- that link is the point of the page. */
.home { margin: 0 0 22px; }
.home a {
  display: inline-block;
  font-family: Georgia, 'Times New Roman', serif;
  font-size: 20px; font-weight: 700; letter-spacing: .01em;
  color: #8a2f1d; text-decoration: none;
  padding: 8px 16px;
  border: 2px solid #8a2f1d;
  border-radius: 2px;
}
.home a:hover { background: #8a2f1d; color: #efe4cd; }
h1 {
  font-family: Georgia, 'Times New Roman', serif;
  font-size: 28px; line-height: 1.25; margin: 0;
}
.meta {
  margin: 8px 0 0; font-size: 11px; letter-spacing: 2px;
  text-transform: uppercase; color: #7a6444;
}
.rule { border: 0; border-top: 2px solid #2b2115; margin: 14px 0 20px; }
h2 {
  font-size: 11px; letter-spacing: 3px; text-transform: uppercase;
  color: #8a2f1d; margin: 22px 0 7px;
}
p {
  font-family: Georgia, 'Times New Roman', serif;
  font-size: 15.5px; line-height: 1.72; margin: 0 0 10px;
}
.flagged { border-left: 3px solid #8a2f1d; padding-left: 14px; }
.empty { font-style: italic; color: #7a6444; }
.foot {
  margin-top: 28px; padding-top: 12px; border-top: 1px solid #c5b391;
  font-size: 10.5px; letter-spacing: 2px; text-transform: uppercase;
  color: #8a7a5c;
}
.foot a { color: #8a2f1d; }
.foot .credit { margin-top: 6px; opacity: .7; }
.thumb { display: block; width: 100%; height: auto; margin-bottom: 22px; }
/* The programme itself, so the page is somewhere to watch rather than only to
   read about. Loaded lazily and from the no-cookie host: a page of notes has no
   business setting tracking cookies before anyone presses play. */
.player {
  position: relative;
  width: 100%;
  aspect-ratio: 16 / 9;
  margin-bottom: 24px;
  background: #05070a;
  box-shadow: 0 0 0 6px #241408, 0 10px 26px rgba(0,0,0,.5);
}
.player iframe {
  position: absolute; inset: 0;
  width: 100%; height: 100%; border: 0;
}
ul.programmes { list-style: none; padding: 0; margin: 0; }
ul.programmes li { border-bottom: 1px solid #d8c9a8; padding: 14px 0; }
ul.programmes li:last-child { border-bottom: 0; }
ul.programmes a {
  font-family: Georgia, 'Times New Roman', serif;
  font-size: 17px; color: #2b2115; text-decoration: none;
}
ul.programmes a:hover { text-decoration: underline; }
ul.programmes .tags {
  display: block; margin-top: 4px; font-size: 10.5px;
  letter-spacing: 2px; text-transform: uppercase; color: #7a6444;
}
/* Already-watched entries recede; the ones still to see stay at full strength. */
ul.programmes li.watched a { color: #7a6444; }
ul.programmes li.part-watched a { color: #2b2115; }
ul.programmes .mark {
  font-style: normal; margin-left: 8px; padding: 1px 5px;
  background: #ded0b2; color: #6a5636; border-radius: 2px; letter-spacing: 1px;
}
ul.programmes li.part-watched .mark { background: #8a2f1d; color: #f3e7d2; }

/* ---- Calendar archive ---- */
.archive { margin-bottom: 26px; }
.archive > h2 {
  font-size: 11px; letter-spacing: 3px; text-transform: uppercase;
  color: #8a2f1d; margin: 0 0 12px;
}
.cal-month { margin-bottom: 16px; }
.cal-month h3 {
  font-family: Georgia, 'Times New Roman', serif;
  font-size: 15px; font-weight: normal; margin: 0 0 7px; color: #4a3a24;
}
.cal-days { display: flex; flex-wrap: wrap; gap: 6px; }
.cal-day {
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  min-width: 42px; padding: 5px 6px;
  background: #e2d4b6; border: 1px solid #cbb894;
  text-decoration: none; color: #2b2115; line-height: 1.15;
}
.cal-day:hover { background: #d3c09b; }
.cal-num { font-size: 14px; font-weight: bold; }
.cal-count {
  font-size: 9px; letter-spacing: 1px; text-transform: uppercase; color: #7a6444;
}
li.date-row { border-bottom: 0 !important; padding: 22px 0 4px !important; }
li.date-row h2 {
  font-size: 11px; letter-spacing: 3px; text-transform: uppercase;
  color: #8a2f1d; margin: 0; display: flex; gap: 10px; align-items: baseline;
}
li.date-row:first-child { padding-top: 0 !important; }
.date-count { font-size: 10px; color: #a08a63; letter-spacing: 1px; }
a.tag-link { color: #8a2f1d; text-decoration: none; border-bottom: 1px dotted #b9917f; }
a.tag-link:hover { background: #e6d6b4; }
@media (max-width: 700px) {
  .sheet { padding: 26px 22px 22px; }
  h1 { font-size: 21px; }
  p { font-size: 14px; line-height: 1.6; }
}
"""


def esc(text):
    return html.escape(str(text), quote=True)


def load_playlist():
    if not PLAYLIST.exists():
        sys.exit(f"{PLAYLIST} does not exist.")
    try:
        data = json.loads(PLAYLIST.read_text())
    except json.JSONDecodeError as exc:
        sys.exit(f"{PLAYLIST} is not valid JSON ({exc}).")
    return data


def summarise(video, station=None, limit=155):
    """A meta description: the first sentences of the summary, or a fallback."""
    doc = video.get("dossier") or {}
    text = (doc.get("summary") or "").strip()
    if not text:
        name = (station or {}).get('title', 'RetroTV')
        return f"{video.get('title', 'A video')} — programme notes from {name}."
    text = re.sub(r"\s+", " ", text)
    if len(text) <= limit:
        return text
    cut = text[:limit].rsplit(" ", 1)[0]
    return cut + "…"


def paragraphs_html(text, flagged=False):
    cls = ' class="flagged"' if flagged else ""
    chunks = [c.strip() for c in re.split(r"\n{2,}", str(text)) if c.strip()]
    return "\n".join(f"<p{cls}>{esc(c)}</p>" for c in chunks)


def video_page(video, base_url, station):
    vid = video["videoId"]
    title = video.get("title", vid)
    doc = video.get("dossier") or {}
    # A canonical or og:url has to be absolute to mean anything. Without a real
    # origin, emitting a relative one points crawlers at nonsense, so we emit
    # nothing and let the build warn instead.
    canonical = f"{base_url}/v/{vid}.html" if base_url else ""
    thumb = f"https://i.ytimg.com/vi/{vid}/maxresdefault.jpg"
    description = summarise(video, station)
    tags = video.get("tags") or []

    body_parts = []
    for key, heading in SECTIONS:
        if doc.get(key):
            body_parts.append(f"<h2>{esc(heading)}</h2>")
            body_parts.append(paragraphs_html(doc[key], flagged=(key == "controversy")))
    if not body_parts:
        body_parts.append('<p class="empty">No notes on file for this one yet.</p>')

    # schema.org VideoObject. uploadDate is deliberately absent: the playlist
    # records when a video was scheduled here, not when it was published to
    # YouTube, and asserting the wrong date is worse than omitting the field.
    ld = {
        "@context": "https://schema.org",
        "@type": "VideoObject",
        "name": title,
        "description": description,
        "thumbnailUrl": thumb,
        "embedUrl": f"https://www.youtube.com/embed/{vid}",
        "url": canonical or None,
        "keywords": ", ".join(tags) if tags else None,
        "isPartOf": {
            "@type": "CreativeWork",
            "name": station.get("title", "RetroTV"),
            **({"url": base_url} if base_url else {}),
        },
    }
    ld = {k: v for k, v in ld.items() if v is not None}

    meta_bits = []
    if tags:
        meta_bits.append(esc(" · ".join(tags)))
    if video.get("addedAt"):
        meta_bits.append("Aired " + esc(video["addedAt"]))

    home = f"{base_url}/" if base_url else "../index.html"
    guide = f"{base_url}/guide.html" if base_url else "../guide.html"

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{esc(title)} — {esc(station.get('title', 'RetroTV'))}</title>
<meta name="description" content="{esc(description)}">
{f'<link rel="canonical" href="{esc(canonical)}">' if canonical else ''}
<link rel="stylesheet" href="../notes.css">
<meta property="og:type" content="video.other">
<meta property="og:title" content="{esc(title)}">
<meta property="og:description" content="{esc(description)}">
<meta property="og:image" content="{esc(thumb)}">
{f'<meta property="og:url" content="{esc(canonical)}">' if canonical else ''}
<meta name="twitter:card" content="summary_large_image">
<script type="application/ld+json">
{json.dumps(ld, indent=2, ensure_ascii=False)}
</script>
{ANALYTICS}
</head>
<body>
<main class="sheet">
<p class="home"><a href="{esc(home)}">&larr; {esc(station.get('title', 'RetroTV'))}</a></p>
<div class="player">
<iframe src="https://www.youtube-nocookie.com/embed/{esc(vid)}"
        title="{esc(title)}"
        loading="lazy"
        allow="accelerometer; encrypted-media; gyroscope; picture-in-picture"
        referrerpolicy="strict-origin-when-cross-origin"
        allowfullscreen></iframe>
</div>
<p class="eyebrow">Programme notes</p>
<h1>{esc(title)}</h1>
<p class="meta">{'  //  '.join(meta_bits)}</p>
<hr class="rule">
{chr(10).join(body_parts)}
<footer class="foot">
<p><a href="{esc(guide)}">Programme guide</a></p>
{RETROTV_CREDIT}
</footer>
</main>
</body>
</html>
"""


def tag_links(tags, prefix=""):
    """Tags rendered as links to their channel archive."""
    if not tags:
        return "untagged"
    return " · ".join(
        f'<a class="tag-link" href="{prefix}c/{esc(t)}.html">{esc(t)}</a>' for t in tags
    )


def channel_page(tag, videos, base_url, station):
    """One page per channel: everything that channel carries, newest first.

    The guide answers "what aired when"; these answer "what is on this channel",
    which is the question someone arriving from a search actually has.
    """
    canonical = f"{base_url}/c/{tag}.html" if base_url else ""
    home = f"{base_url}/" if base_url else "../index.html"
    guide = f"{base_url}/guide.html" if base_url else "../guide.html"

    items = []
    for video in videos:
        vid = video["videoId"]
        others = [t for t in (video.get("tags") or []) if t != tag]
        extra = f'<span class="tags">also on {tag_links(others, "../")}</span>' if others else ""
        items.append(
            f'<li data-id="{esc(vid)}">'
            f'<a href="../v/{esc(vid)}.html">{esc(video.get("title", vid))}</a>{extra}</li>'
        )

    described = sum(1 for v in videos if (v.get("dossier") or {}))
    ld = {
        "@context": "https://schema.org",
        "@type": "CollectionPage",
        "name": f"{tag.title()} — {station.get('title', 'RetroTV')}",
        **({"url": canonical} if canonical else {}),
        "hasPart": [
            {
                "@type": "VideoObject",
                "name": v.get("title", v["videoId"]),
                **({"url": f"{base_url}/v/{v['videoId']}.html"} if base_url else {}),
            }
            for v in videos
        ],
    }

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{esc(tag.title())} — {esc(station.get('title', 'RetroTV'))}</title>
<meta name="description" content="Everything on the {esc(tag)} channel of {esc(station.get('title', 'RetroTV'))} — {len(videos)} programmes, {described} with notes.">
{f'<link rel="canonical" href="{esc(canonical)}">' if canonical else ''}
<link rel="stylesheet" href="../notes.css">
<script type="application/ld+json">
{json.dumps(ld, indent=2, ensure_ascii=False)}
</script>
{ANALYTICS}
</head>
<body>
<main class="sheet">
<p class="home"><a href="{esc(home)}">&larr; {esc(station.get('title', 'RetroTV'))}</a></p>
<p class="eyebrow">Channel</p>
<h1>{esc(tag.title())}</h1>
<p class="meta">{len(videos)} programmes · {described} with notes</p>
<hr class="rule">
<ul class="programmes" id="programmes">
{chr(10).join(items)}
</ul>
<footer class="foot">
<p><a href="{esc(guide)}">Programme guide</a></p>
{RETROTV_CREDIT}
</footer>
</main>
{WATCHED_SCRIPT}
</body>
</html>
"""


def post_page(post, videos_by_id, base_url, station):
    canonical = f"{base_url}/p/{post['slug']}.html" if base_url else ""
    home = f"{base_url}/" if base_url else "../index.html"
    guide = f"{base_url}/guide.html" if base_url else "../guide.html"
    body, mentioned = render_markdown(post["body"], videos_by_id, prefix="../")

    listed = ""
    if mentioned:
        rows = "".join(
            f'<li data-id="{esc(v)}"><a href="../v/{esc(v)}.html">'
            f'{esc(videos_by_id[v].get("title", v))}</a></li>'
            for v in mentioned
        )
        listed = ('<h2>Programmes mentioned</h2>'
                  f'<ul class="programmes" id="programmes">{rows}</ul>')

    ld = {
        "@context": "https://schema.org",
        "@type": "BlogPosting",
        "headline": post["title"],
        **({"description": post["summary"]} if post["summary"] else {}),
        **({"datePublished": post["date"]} if post["date"] else {}),
        **({"url": canonical} if canonical else {}),
        "isPartOf": {"@type": "CreativeWork", "name": station.get("title", "RetroTV"),
                     **({"url": base_url} if base_url else {})},
    }

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{esc(post['title'])} — {esc(station.get('title', 'RetroTV'))}</title>
<meta name="description" content="{esc(post['summary'] or post['title'])}">
{f'<link rel="canonical" href="{esc(canonical)}">' if canonical else ''}
<link rel="stylesheet" href="../notes.css">
<meta property="og:type" content="article">
<meta property="og:title" content="{esc(post['title'])}">
<meta property="og:description" content="{esc(post['summary'] or post['title'])}">
{f'<meta property="og:url" content="{esc(canonical)}">' if canonical else ''}
<script type="application/ld+json">
{json.dumps(ld, indent=2, ensure_ascii=False)}
</script>
{ANALYTICS}
</head>
<body>
<main class="sheet">
<p class="home"><a href="{esc(home)}">&larr; {esc(station.get('title', 'RetroTV'))}</a></p>
<p class="eyebrow">From the station</p>
<h1>{esc(post['title'])}</h1>
<p class="meta">{esc(post['date'])}</p>
<hr class="rule">
{body}
{listed}
<footer class="foot">
<p><a href="{esc(guide)}">Programme guide</a></p>
{RETROTV_CREDIT}
</footer>
</main>
{WATCHED_SCRIPT}
</body>
</html>
"""


def guide_page(videos, base_url, station, posts=()):
    canonical = f"{base_url}/guide.html" if base_url else ""
    home = f"{base_url}/" if base_url else "index.html"

    # Group by airdate so the guide reads as an archive rather than one long list.
    # With hundreds of programmes, a flat list is unusable: the calendar is the
    # only way to find "the thing from that Friday".
    by_date = {}
    for video in videos:
        by_date.setdefault(str(video.get("addedAt") or "undated"), []).append(video)
    dates = sorted(by_date, reverse=True)

    # The calendar strip: months, each showing the days that carry programmes.
    months = {}
    for date in dates:
        months.setdefault(date[:7] if date != "undated" else "undated", []).append(date)

    cal_blocks = []
    for month in sorted(months, reverse=True):
        if month == "undated":
            label = "Undated"
        else:
            y, m = month.split("-")
            label = f"{MONTH_NAMES[int(m) - 1]} {y}"
        days = []
        for date in months[month]:
            n = len(by_date[date])
            day = date[8:10] if date != "undated" else "?"
            days.append(
                f'<a class="cal-day" href="#d-{esc(date)}">'
                f'<span class="cal-num">{esc(day.lstrip("0") or day)}</span>'
                f'<span class="cal-count">{n}</span></a>'
            )
        cal_blocks.append(
            f'<div class="cal-month"><h3>{esc(label)}</h3>'
            f'<div class="cal-days">{"".join(days)}</div></div>'
        )

    posts_block = ""
    if posts:
        rows = "".join(
            f'<li><a href="p/{esc(p["slug"])}.html">{esc(p["title"])}</a>'
            f'<span class="tags">{esc(p["date"])}{" · " + esc(p["summary"]) if p["summary"] else ""}</span></li>'
            for p in posts
        )
        posts_block = ('<nav class="archive"><h2>Reading</h2>'
                       f'<ul class="programmes">{rows}</ul></nav>')

    items = []
    for date in dates:
        group = by_date[date]
        if date == "undated":
            heading = "Undated"
        else:
            y, m, d = date.split("-")
            heading = f"{d.lstrip('0')} {MONTH_NAMES[int(m) - 1]} {y}"
        items.append(
            f'<li class="date-row" id="d-{esc(date)}">'
            f'<h2>{esc(heading)}<span class="date-count">{len(group)}</span></h2></li>'
        )
        for video in group:
            vid = video["videoId"]
            tags = video.get("tags") or []
            # data-id lets the guide mark what this visitor has already watched. The
            # marking happens in their browser, from the same localStorage the set
            # uses, so the page itself stays static and identical for everyone.
            items.append(
                f'<li data-id="{esc(vid)}">'
                f'<a href="v/{esc(vid)}.html">{esc(video.get("title", vid))}</a>'
                f'<span class="tags">{tag_links(tags)}</span></li>'
            )

    ld = {
        "@context": "https://schema.org",
        "@type": "CollectionPage",
        "name": f"Programme guide — {station.get('title', 'RetroTV')}",
        **({"url": canonical} if canonical else {}),
        "hasPart": [
            {
                "@type": "VideoObject",
                "name": v.get("title", v["videoId"]),
                "url": (f"{base_url}/v/{v['videoId']}.html" if base_url
                        else f"v/{v['videoId']}.html"),
            }
            for v in videos
        ],
    }

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Programme guide — {esc(station.get('title', 'RetroTV'))}</title>
<meta name="description" content="Every programme broadcast on {esc(station.get('title', 'RetroTV'))}, with notes on what each one is and why it matters.">
{f'<link rel="canonical" href="{esc(canonical)}">' if canonical else ''}
<link rel="stylesheet" href="notes.css">
<script type="application/ld+json">
{json.dumps(ld, indent=2, ensure_ascii=False)}
</script>
{ANALYTICS}
</head>
<body>
<main class="sheet">
<p class="home"><a href="{esc(home)}">&larr; {esc(station.get('title', 'RetroTV'))}</a></p>
<p class="eyebrow">{esc(station.get('title', 'RetroTV'))}</p>
<h1>Programme guide</h1>
<p class="meta">{len(videos)} programmes on file · {len(dates)} broadcast {"day" if len(dates) == 1 else "days"}</p>
<hr class="rule">
{posts_block}
<nav class="archive">
<h2>Archive</h2>
{chr(10).join(cal_blocks)}
</nav>
<ul class="programmes" id="programmes">
{chr(10).join(items)}
</ul>
<footer class="foot">
<p id="watchedSummary"></p>
{RETROTV_CREDIT}
</footer>
</main>
{WATCHED_SCRIPT}
</body>
</html>
"""


def sitemap(videos, base_url, tags=(), posts=()):
    today = dt.date.today().isoformat()
    urls = [f"{base_url}/", f"{base_url}/guide.html"]
    urls += [f"{base_url}/c/{t}.html" for t in tags]
    urls += [f"{base_url}/p/{p['slug']}.html" for p in posts]
    urls += [f"{base_url}/v/{v['videoId']}.html" for v in videos]
    entries = "\n".join(
        f"  <url><loc>{esc(u)}</loc><lastmod>{today}</lastmod></url>" for u in urls
    )
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
{entries}
</urlset>
"""


def station_manifest(videos, base_url, station, psa, tags):
    """The machine-readable half of the station: what another RetroTV needs to
    follow this one without a human reading playlist.json by hand.

    Channels are derived from the tags actually carried by the schedule, the
    same source channel_page() reads from, rather than duplicating the
    CHANNELS array that lives in index.html -- one source of truth for what a
    channel is, so this can never drift out of step with the dial itself.
    """
    channels = []
    for tag in tags:
        carried = [v for v in videos if tag in (v.get("tags") or [])]
        channels.append({
            "id": tag,
            "label": tag.title(),
            "url": f"{base_url}/c/{tag}.html",
            "count": len(carried),
        })

    bulletin = None
    if psa and psa.get("text"):
        bulletin = {
            "text": psa["text"],
            "postedAt": psa.get("postedAt"),
            "hours": psa.get("hours"),
        }

    latest = [
        {
            "videoId": v["videoId"],
            "title": v.get("title", v["videoId"]),
            "tags": v.get("tags") or [],
            "addedAt": v.get("addedAt"),
            "url": f"{base_url}/v/{v['videoId']}.html",
            **({"source": v["source"]} if v.get("source") else {}),
        }
        for v in videos[:LATEST_COUNT]
    ]

    return {
        "spec": STATION_SPEC,
        "station": station.get("title", "RetroTV"),
        "url": base_url,
        "channels": channels,
        "playlist": f"{base_url}/playlist.json",
        "bulletin": bulletin,
        "latest": latest,
    }


def robots(base_url):
    # Answering LLM crawlers explicitly rather than by omission: the notes exist
    # to be read and cited, so the crawlers that do that are welcomed by name.
    return f"""User-agent: *
Allow: /

User-agent: GPTBot
Allow: /

User-agent: ClaudeBot
Allow: /

User-agent: PerplexityBot
Allow: /

Sitemap: {base_url}/sitemap.xml
"""


def main():
    parser = argparse.ArgumentParser(description="Generate this RetroTV station's static pages.")
    parser.add_argument("--base-url", help="e.g. https://your-station.vercel.app "
                                           "(default: the 'site.url' in playlist.json)")
    args = parser.parse_args()

    data = load_playlist()
    station = data.get("site") or {}
    base_url = (args.base_url or station.get("url") or "").rstrip("/")
    videos = [v for v in data.get("playlist", []) if v.get("videoId")]
    videos.sort(key=lambda v: str(v.get("addedAt", "")), reverse=True)

    if VIDEO_DIR.exists():
        shutil.rmtree(VIDEO_DIR)
    VIDEO_DIR.mkdir(parents=True)

    for video in videos:
        (VIDEO_DIR / f"{video['videoId']}.html").write_text(
            video_page(video, base_url, station)
        )

    (ROOT / "notes.css").write_text(STYLESHEET)

    posts = read_posts()
    videos_by_id = {v["videoId"]: v for v in videos}
    if POST_OUT.exists():
        shutil.rmtree(POST_OUT)
    POST_OUT.mkdir(parents=True)
    for post in posts:
        (POST_OUT / f"{post['slug']}.html").write_text(
            post_page(post, videos_by_id, base_url, station)
        )

    (ROOT / "guide.html").write_text(guide_page(videos, base_url, station, posts))

    # One page per channel. Rebuilt from scratch so a tag that stops being used
    # doesn't leave an orphan page behind advertising programmes it no longer has.
    if CHANNEL_DIR.exists():
        shutil.rmtree(CHANNEL_DIR)
    CHANNEL_DIR.mkdir(parents=True)
    tags = sorted({t for v in videos for t in (v.get("tags") or [])})
    for tag in tags:
        carried = [v for v in videos if tag in (v.get("tags") or [])]
        (CHANNEL_DIR / f"{tag}.html").write_text(
            channel_page(tag, carried, base_url, station)
        )

    if base_url:
        (ROOT / "sitemap.xml").write_text(sitemap(videos, base_url, tags, posts))
        (ROOT / "robots.txt").write_text(robots(base_url))
        (ROOT / "station.json").write_text(
            json.dumps(station_manifest(videos, base_url, station, data.get("psa"), tags),
                       indent=2, ensure_ascii=False)
        )
    else:
        # Without a real origin these two files would advertise wrong URLs, which
        # is worse than not shipping them.
        for name in ("sitemap.xml", "robots.txt", "station.json"):
            (ROOT / name).unlink(missing_ok=True)

    with_notes = sum(1 for v in videos if (v.get("dossier") or {}))
    print(f"Built {len(videos)} programme pages ({with_notes} with notes), "
          f"{len(tags)} channel pages, {len(posts)} posts, guide.html")
    if base_url:
        print(f"       sitemap.xml, robots.txt and station.json for {base_url}")
    else:
        print("       no site.url set -- skipped sitemap.xml and robots.txt.")
        print('       Set it with: "site": {"url": "https://..."} in playlist.json')


if __name__ == "__main__":
    main()
