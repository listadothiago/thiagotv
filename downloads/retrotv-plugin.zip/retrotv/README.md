# RetroTV

A retro television set on the web that broadcasts your own hand-picked YouTube
playlist. Static site, no build step, no backend, no API key, no database.
Two files decide everything you see: `index.html` is the television —
player, channel dial, off-air cards — and `playlist.json` is the schedule.

This copy ships with a small demo lineup across ten channels — Music, Films,
History, Science, Nature, Cartoon, Infomercials, Drag, Comedy, Vignette — plus
a text-only Bulletin channel, so you have something to watch immediately and a
working example of every feature. Replace it with your own.

## Get it running

```bash
python3 -m http.server 8000
```

Open <http://localhost:8000>. The plain `file://` route does not work — the
YouTube player needs a real origin, not a local file path.

## Open this folder in Claude Code

There's a skill in `.claude/skills/retrotv/` that does the actual station
management for you — adding videos, tagging them onto channels, writing the
notes that make each programme page worth finding, publishing. Open this
folder in Claude Code and just talk to it: paste a YouTube link, ask it to
find videos for a channel you want, or ask it to walk you through naming and
deploying your station. See "Making it yours" below for what it can do.

## Rename it

The name in the on-screen brand, the browser tab, and every generated page
comes from `playlist.json`, not from the code:

```bash
python3 scripts/tv.py brand "Your Station Name"
```

This updates `playlist.json`, `index.html` and `manifest.webmanifest` in one
go. Follow it with a rebuild (see below) so the generated pages pick it up too.

## Running the station

`scripts/tv.py` edits `playlist.json` so you don't have to hand-edit it.

```bash
python3 scripts/tv.py add <url-or-id> [--title T] [--tags music,films] [--date YYYY-MM-DD]
python3 scripts/tv.py channels                            # the dial, and how full each channel is
python3 scripts/tv.py inspect <url-or-id>                 # what a video is, without adding it
python3 scripts/tv.py list [--tag TAG] [--missing-notes]
python3 scripts/tv.py tag <url-or-id> --tags music         # replace tags
python3 scripts/tv.py tag <url-or-id> --add-tags vignette  # append
python3 scripts/tv.py rm <url-or-id>
python3 scripts/tv.py date <url-or-id> <YYYY-MM-DD>
python3 scripts/tv.py bump <url-or-id>                     # repost to the front of Latest
python3 scripts/tv.py doc <url-or-id> --summary "..." --relevance "..." --controversy "..."
python3 scripts/tv.py psa set "text" [--hours N]            # the Bulletin channel
python3 scripts/tv.py post new <slug> --title "..."         # a long-form piece, listed in the guide
```

Titles are fetched from YouTube automatically. Any link shape works — watch,
youtu.be, shorts, embed — or a bare video id.

## How the station works

**Tags are channels.** A video's `tags` decide which channels carry it. A tag
only becomes a watchable channel once it also appears in the `CHANNELS` array
in `index.html`; a tag without a channel entry is invisible. A video can carry
several tags at once.

**`addedAt` is an airdate.** The Latest channel leads with the newest thing
*this viewer hasn't seen yet* — post or bump something and it becomes the
first unseen video, for everyone. Backdate or post-date freely; it's a
schedule, not a timestamp.

**Channels remember where you are.** Each channel keeps its own running order
and cursor for the session. Tuning away burns the video you were on, so coming
back lands on the next one. Once a channel has played everything it carries it
signs off with colour bars or a test card, and starts a fresh shuffle next time
you tune in. Turning the power off and back on starts a new session — Latest
always leads fresh.

**Long-form channels pick up where you left off.** A channel marked
`resume: true` in `CHANNELS` remembers how far into a video you got, capped at
a couple of attempts before it lets go and moves on. Set it for anything
long-form — films, documentaries, full episodes.

**Short things play between programmes.** Videos tagged with any channel in
`INTERSTITIAL_TAGS` (ads and vignette, by default) have a chance of showing up
as a brief break between one programme and the next, the way a station used to
fill the seams with adverts and idents. Anything the player discovers is over a
minute long is dropped from the pool on the spot — no separate step needed.

**Broken videos are skipped automatically.** The player judges a video by
whether it actually starts, not by the error code YouTube reports. Anything
that never starts — deleted, private, embedding-disabled, region-blocked — is
dropped from every channel for that session.

**The set remembers what a viewer watched**, entirely in their own browser.
Nothing is sent anywhere. There's a reset link under the set.

## Programme notes and SEO

Each video can carry notes — what it is, why it matters, any documented
controversy — published as a real, crawlable page per video (`v/<id>.html`),
plus a page per channel (`c/<tag>.html`) and a calendar-style guide
(`guide.html`). The television itself is a JavaScript application and search
engines mostly can't read it; these generated pages are the site's actual text
presence, and they're what get found. Ten of this template's example videos
already carry real notes, so you can see the shape.

Longer pieces — a round-up of what's new, an essay about an archive you've
built — live in `posts/*.md` and publish at `/p/<slug>.html`, listed under
"Reading" at the top of the guide.

## Publishing

```bash
python3 scripts/build.py --base-url https://your-site.example
./scripts/publish.sh "add a banger to the music channel"
```

`publish.sh` rebuilds the generated pages before committing and pushing, so
the static pages never drift out of sync with the schedule — set up a `git`
remote and a host (GitHub Pages, Vercel, Netlify, anything that serves static
files) and this is the only command you need afterwards. Run `build.py` once
with `--base-url` pointed at your real domain so the sitemap, canonical URLs
and `robots.txt` all resolve correctly; after that `publish.sh` remembers it
via `site.url` in `playlist.json`.

## Making it yours

Everything above is what the scripts do. The skill in `.claude/skills/retrotv/`
is what turns that into a conversation — open this folder in Claude Code and
it will help you rename the station, get it deployed, and build out channels
around whatever you're actually into. It's worth reading if you want to
understand how it thinks about the station, but you don't have to: just start
talking to it.
