---
name: retrotv
description: Set up, manage and grow a RetroTV station — a retro television web app that broadcasts a hand-picked YouTube playlist. Covers first-time setup (naming the station, running it locally, deploying it), adding and tagging videos, creating channels, writing programme notes, posting bulletins, and proactively finding videos and building out channels around whatever the user is into. Use this skill whenever the user opens this project, mentions their RetroTV / the station / the TV / their channels, pastes a YouTube link or playlist link with little or no instruction (the most common way a station gets updated), or asks what to do next with the project — even if they don't name the skill or a file directly.
---

# RetroTV

RetroTV is a static retro-TV page that plays a YouTube playlist. Everything it
shows comes from `playlist.json` at the project root. There is no database and
no YouTube API key — the file *is* the schedule.

You are talking to whoever owns this particular station. They may be setting
it up for the first time, or they may have been running it for a while — check
`playlist.json` and `git log` before assuming which, rather than asking.

## If this looks like a first visit

Signs of a first visit: there's no `.git` folder yet (or `git log` is empty),
no `origin` remote, and the playlist is still the handful of demo videos this
template shipped with. When you see that, say so and offer to
walk through getting the station live — don't wait to be asked, and don't
dump a checklist; go one step at a time.

1. **Name it.** `python3 scripts/tv.py brand "Whatever they want to call it"`.
   Ask if they haven't said, but don't block on it — "RetroTV" is a perfectly
   fine name to start with and it's a one-line command to change later.
2. **Show it running.** `python3 -m http.server 8000` and point them at
   `http://localhost:8000`. Mention that a plain double-clicked `index.html`
   won't work — the YouTube player needs a real origin.
3. **Ask what they actually want on it.** Not "what videos do you want" in the
   abstract — ask about interests, shows, eras, artists, genres. This is the
   information you'll use in the next section.
4. **Get it deployed**, once they seem ready. You cannot create GitHub repos,
   Vercel projects, or push credentials yourself — those need the user's own
   accounts and clicks. What you *can* do: initialise git, write the remote-add
   command, and run `publish.sh` the moment a remote exists. Walk them through
   it like this:
   - "Create an empty repo on GitHub (github.com/new, no README/gitignore),
     then tell me the URL."
   - `git init`, first commit, `git remote add origin <url>`, then push.
   - "Import that repo on Vercel (or Netlify, or GitHub Pages) — whichever you
     prefer, it's just static files." Get the live URL from them.
   - `python3 scripts/build.py --base-url https://their-real-domain` once,
     then `./scripts/publish.sh` from then on.

Don't front-load all of this in one message. Setup is a conversation, not a
form.

## The mental model: it's a TV station, not a playlist

The reason the data looks the way it does is that a station is being run, not
a playlist maintained. Two fields carry that:

- **`tags`** decide which channels a video appears on. A video can be on
  several.
- **`addedAt`** decides where it sits in the running order on the *Latest*
  channel, which leads with the newest thing this viewer hasn't seen yet.

So `addedAt` is really an airdate, not a bookkeeping timestamp. If the user
says "this goes out Friday night", set `addedAt` to that Friday. Backdating a
batch import is normal too — see "Adding many at once" below.

Check the `CHANNELS` array in `index.html` for the live channel list rather
than trusting any list written here — it's the kind of thing that drifts as
the user's station grows.

## Use the script

`scripts/tv.py` handles the JSON so nobody has to hand-edit it. Run it from
the project root — the project you're sitting in right now, wherever that is
on this machine. The script resolves its own paths, so this works no matter
where the user put the folder.

```
python3 scripts/tv.py add <url-or-id> [--title T] [--tags music,films] [--date YYYY-MM-DD]
python3 scripts/tv.py list [--tag TAG] [--missing-notes]
python3 scripts/tv.py tag <url-or-id> --tags music,films      # replace
python3 scripts/tv.py tag <url-or-id> --add-tags vignette     # append
python3 scripts/tv.py rm <url-or-id>
python3 scripts/tv.py date <url-or-id> <YYYY-MM-DD>
python3 scripts/tv.py bump <url-or-id>                        # repost to the front of Latest
python3 scripts/tv.py brand "Station Name"                    # rename the station everywhere
```

`add` accepts any YouTube link shape (watch, youtu.be, shorts, embed) or a bare
11-character id, and fetches the real title from YouTube automatically. Only
pass `--title` when the user wants something different from the official
title — a station-style name like "Friday Night Sci-Fi: Solaris" is often what
they're after.

## Working with the user

**Don't interrogate them.** A bare link with no instructions is enough to act
on: work out where it belongs, put it there, and say what you chose. Asking a
question per field turns a five-second task into a form, and every choice here
is one command to undo.

### Placing a video with no instructions

```
python3 scripts/tv.py channels          # what exists, and how full each channel is
python3 scripts/tv.py inspect <url>     # title and uploading channel, without adding
```

Run `channels` first — the lineup drifts, and guessing at a tag that has no
channel means the video lands somewhere invisible. Then `inspect`, whose title
and uploader are usually enough to place a video: a VEVO or artist upload is
`music`, a full feature is `films`, a documentary is `history`, `nature` or
`science` depending on subject, an animated short is `cartoon`.

**Prefer an existing channel.** Reach for the nearest reasonable one rather
than an exact one. A stand-up clip belongs in `comedy` even without a
`standup` channel; splitting hairs produces a dial full of near-duplicates.

**The dial is Latest plus one channel per tag.** There is no catch-all shuffle
channel — Latest covers "what's new" and every other position is a tag. A
video with no tag is reachable only from Latest, and once seen, effectively
gone. Always tag.

**A video can carry several tags**, and that's often the honest answer — a
music documentary is `music` and `history` both.

### When to create a channel

Only when the video genuinely has no home *and* more like it are likely. A
channel with one video plays that same video to anyone who tunes in, which is
worse than an approximate home. Creating one means two edits, both required —
a tag without a channel entry is invisible on the dial:

1. `add` the video with the new tag
2. add the entry to `CHANNELS` in `index.html`, with `order: 'shuffle'`, plus
   `resume: true` if the content is long-form

Position it on the dial by importance: the array order is the order the knob
cycles through, and with no numbers or names on screen, the far end of the
dial is the hardest place to reach. Keep `Bulletin` last — it's a notice
board, not something to trip over on the way from Latest to anything else.

Two flags worth setting deliberately:

- `repeat: false` — the channel carries only what this viewer hasn't seen and
  goes to a card when they're caught up. Right for a channel whose promise is
  newness (Latest is the only one that should have this).
- `resume: true` — the channel remembers how far into a video the viewer got.
  Worth setting for anything long-form; pointless for short clips.

**Interstitials.** Videos tagged with whatever channels are listed in
`INTERSTITIAL_TAGS` inside `index.html` (ships as `ads` and `vignette`) have a
chance of playing as a short break between programmes on
*any* channel, the way a station fills the seams with adverts and idents. The
player checks the length itself the moment a candidate loads and drops
anything over a minute from the pool on the spot — there's no separate
duration-checking step to run. If the user wants a new interstitial pool (a
`stings` tag, say), just add that tag to `INTERSTITIAL_TAGS` in `index.html`.

**Say what you decided and why, in one line.** "Put it on Nature — it's a
wildlife documentary" is enough. **When you genuinely can't tell** what a
video is, ask rather than guessing — a wrong tag is quiet, it doesn't error,
it just puts the video somewhere it makes no sense.

### Adding many at once

Looping `add` is fine. **Backdate a batch import** rather than letting it land
on today's date — a hundred-video playlist import dated today would flood
Latest and bury everything the user chose one at a time. An older date (a
week or a month back) keeps the batch present in its channel without
dominating the front page.

Report a batch as a short list at the end, not one message per video.

## Finding videos for the user — do this proactively

This is not a passive skill that waits for links. When a channel is thin, when
the user seems unsure what to add, or when they mention an interest in
passing ("I love giallo horror", "get me some 90s R&B"), **offer to go find
some** rather than waiting for them to paste links themselves.

You can search YouTube directly — its search-results page is scrapeable the
same way playlist pages are, no API key needed. Given a query, fetch
`https://www.youtube.com/results?search_query=<url-encoded query>` and pull
`videoId`/title pairs out of the response the same way `inspect` and the
playlist-import flow already do. This gives you real candidates: title,
channel, video id.

The workflow:

1. Ask what they're actually into, if it isn't already clear — genre, era,
   specific artists or shows, mood. This is a real question, not a formality;
   better input here means better suggestions.
2. Search, and come back with a **short list** — five or six candidates with
   title and uploader, not a wall of links. Searching originates suggestions
   *you* are choosing, unlike a link the user hands you directly, so show the
   shortlist before adding rather than acting unprompted. Note anything
   uncertain (an unofficial-looking upload, an ambiguous title).
3. Once they pick — or say "add them all", which is a fine answer — tag and
   add them the normal way, offer to write notes for the ones you can speak to
   accurately, and publish.
4. If a channel stays thin (two or three videos) after a session, say so next
   time it comes up: "Nature's only got three things in it — want me to find
   a few more?" Don't nag every message, but don't let a bare channel sit
   unmentioned forever either.

**The same non-fabrication rule as everywhere else applies to search results.**
A video's *existence* is a fact you can verify by looking it up. What it means
culturally, who's in it, whether it's actually good — don't claim confidence
you don't have just because you found it in a search.

## Reposting

`bump` puts a video back at the head of the Latest channel, dated today. Use
it when the user says to bump, repost, re-air, bring back or feature
something.

It is a repost, not a correction: tags and notes are untouched, and anyone who
already watched it still has it marked as watched, so it isn't forced on them
a second time. Two things happen together — the date moves to today *and* the
entry moves to the front of the file, because several videos usually share a
date and file order breaks the tie. `date` alone puts a video *among* today's,
not at the head; don't reach for it when the user means "put this first."

## Posts

Longer pieces live in `posts/*.md` and publish at `/p/<slug>.html`, listed
under "Reading" at the top of the guide. The television itself never changes —
that's the point of putting them there.

```
python3 scripts/tv.py post new <slug> --title "..." --summary "..."
python3 scripts/tv.py post list
python3 scripts/tv.py post digest [--days N | --since YYYY-MM-DD]
```

A post is markdown with a small frontmatter block, plus `[[videoId]]`, which
becomes a link carrying that programme's real title — so a post can't drift
out of step with the schedule, and every programme referenced that way is
collected into a "Programmes mentioned" list automatically.

**Never write an id from memory.** Get it from `post digest`, `list` or
`inspect` and paste it. An invented id is caught at build time and printed as
a warning — heed it, don't ship past it.

**Why posts matter more than they look like they should:** one good piece
about an archive of a hundred adverts will outperform a hundred thin pages
about individual adverts, and it's honest in a way those pages wouldn't be —
writing a hundred accurate articles about individual commercials isn't
something anyone can actually do. Posts also link out to dozens of programme
pages, which is how those pages get found.

For a round-up post: start with `post digest` for the real numbers (never
recall them from memory), then group by whatever's actually interesting this
time rather than forcing the same shape every time, feature a handful of
programmes with `[[videoId]]`, and give it a title someone would click — never
"Weekly update."

## Programme notes

Each video can carry notes: what it is, why it matters, any documented
controversy. They don't appear on the front page — the television is the
whole of the front page — but they publish as `v/<id>.html`, one page per
video, linked from the guide. Those pages are what search engines and LLM
crawlers actually read, so the notes are the site's entire text presence.

```
python3 scripts/tv.py doc <url-or-id> --summary "..." --relevance "..." --controversy "..."
python3 scripts/tv.py doc <url-or-id>            # print what's on file
python3 scripts/tv.py doc <url-or-id> --clear
```

**Writing these is real work worth doing, not a favour.** When you add a
video you're confident about, offer to write its notes in the same turn
rather than treating it as a separate ask. A video with no notes ships a thin
page.

**Go deep when you write them.** These pages are the entire text presence of
a site whose front page is a television — length and substance are the point.
Several paragraphs per section, not a line each: what the thing is and how it
was made, the scene it came from, what changed because of it. `\n\n` inside a
value gives you paragraph breaks — use them.

- **Summary**: what the thing concretely *is* — who made it, when, what it
  sounds or looks like. Not a plot recap, not marketing copy.
- **Why it matters**: the honest cultural claim. If a video is simply
  enjoyable with no wider significance, leave the section out rather than
  inflating it.
- **Controversy**: only when something real and documented happened. It
  renders with a marked margin, so it isn't for trivia.

**Don't invent facts. This is the one rule that matters most in this whole
skill.** These notes publish under the user's name on a site meant to be
cited. If you aren't confident about a date, a credit, a chart position, or
who did what — leave it out, or say plainly you're unsure and ask. A vague
true sentence beats a specific false one. If you don't know a video, say so.

## The Bulletin channel

One channel carries no video: **Bulletin** shows a paragraph of text the user
posts, and it expires on its own.

```
python3 scripts/tv.py psa set "text" [--hours N]   # default 24h
python3 scripts/tv.py psa show                     # what's on air, time left
python3 scripts/tv.py psa clear                    # pull it early
```

There is only ever one bulletin — `set` replaces whatever was there. Expiry is
decided in the viewer's browser, not by anything deleting the record, which is
how a bulletin can age out on a site with nothing running server-side.

**Write it as broadcast copy**: a few sentences, no markdown, no links (they
aren't clickable), no headings. Match how the user phrased their request
rather than formalising it — the bulletin is the station's voice.

## Availability is the page's problem, not yours

Don't try to verify a video will play before adding it. The player watches
whether each video actually starts, and silently skips any that don't —
removed, private, embedding-disabled, region-blocked. If `add` fails because
the title lookup returned "private or embedding-disabled" or "not found",
the video probably won't play either way — tell the user rather than working
around it with a manual `--title`.

## Publishing

The default for this skill is to publish every change in the same turn it's
made — add a video, retag one, write notes, post a bulletin, all of it ends
with `./scripts/publish.sh "what changed"`. That's worth saying plainly the
first time it comes up, so it's a known default rather than a surprise: if the
user would rather review changes before they go live, they can just say so
and you hold off until asked.

```
./scripts/publish.sh "add a banger to the music channel"
```

The script rebuilds the generated pages before committing, so never publish
by hand with raw git commands — that would push a schedule whose programme
pages no longer match it. Before the first publish, there needs to be a git
remote — see "If this looks like a first visit" above.

Write the commit message as a short station-log line — "add two nature
shorts", "new comedy channel" — it's the only history of how the schedule
evolved.

Batch first, publish once, when handling several videos in one go. Two things
to still stop for: **deletions** (confirm before pushing one — easy to publish,
awkward to walk back), and **a failed push** (report what git said rather than
retrying blindly; an auth failure, a rejected non-fast-forward, and no network
are different problems with different fixes).
